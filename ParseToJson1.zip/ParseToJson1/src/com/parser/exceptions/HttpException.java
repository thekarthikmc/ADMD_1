package com.parser.exceptions;

@SuppressWarnings("serial")
public class HttpException extends Exception {

	String errMsg;
	
	public HttpException(int code, String msg)
	{
		
		String errormsg = "Invalid Json data";
		errMsg	= "Request failed Code: "+code+" Error Message: "+msg+" Probable reason:"+errormsg;
		System.out.println(errMsg);
	}
	
	public String toString()
	{
		return errMsg;
	}
}
