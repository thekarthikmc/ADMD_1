package com.parser.exceptions;

@SuppressWarnings("serial")
public class ElasticException extends Exception {

	String errMsg="";
	
	public ElasticException(int code, String msg)
	{
		if(code == 400)
		{
			String msg1= "Invalid Json_NewLine character is Missing";
			
		//	System.out.println(msg);
			
		errMsg	= "Request failed Code: "+code+" Error Message: "+msg+" \n Probable Reason:"+msg1;
		}
		
		if(code == 200)
		{
		
			String msg1= "Invalid Json_Data _format";
		
		errMsg	= "Request failed Code: "+code+" Error Message: "+msg+" \n Probable Reason: "+msg1;
		
		}
	}
	
	public String toString()
	{
		return errMsg;
	}
}
