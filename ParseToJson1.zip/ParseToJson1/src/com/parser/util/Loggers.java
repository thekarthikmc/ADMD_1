package com.parser.util;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Loggers {

	public static Logger log = Logger.getLogger(Loggers.class);
	
	static{
		PropertyConfigurator.configure("log4j.properties");
	}
	

}
