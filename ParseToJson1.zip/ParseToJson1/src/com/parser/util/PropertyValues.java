package com.parser.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyValues {
	
	public static Properties prop;
	

	public Properties loadProperties()
	{
		prop = new Properties();
		InputStream input = null;		
		
		try {
			input = new FileInputStream("project.properties");
			// load a properties file
			
			prop.load(input);

			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return prop;
	}
	
	public Properties getProperties()
	{
		return prop;
	}
	
}
