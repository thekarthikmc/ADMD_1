package com.parser.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.parser.exceptions.ElasticException;
import com.parser.exceptions.HttpException;

public class HttpCalls {
	
	
	//static Logger log = Logger.getLogger(HttpCalls.class.getName());
	
	Properties prop;
	
	public HttpCalls()
	{
		this.prop 		  = PropertyValues.prop;
	}
	
	public String[] httpCall(String url, Map<String,String> headers, int timeout, String data, String httpType) throws HttpException, ElasticException
	{
		StringBuilder response	= new StringBuilder();
		String[] resp 			= new String[2];
		int responseCode 		= 0;
		
		try
		{
			URL obj = new URL(url);
			
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();			
			
			con.setDoInput(true);			   //To set the connection 
			if(headers != null)
			{
				for(Map.Entry<String, String> entry:headers.entrySet())
				{
					con.setRequestProperty(entry.getKey(), entry.getValue());
				}
			}
			con.setConnectTimeout(timeout);
			con.setRequestMethod(httpType);
			
			String httpTypes = prop.getProperty("httpBody");
				
			if(Arrays.asList(httpTypes.split(",")).contains(httpType))
			{
				con.setDoOutput(true);
				if(data!=null)
				{
					OutputStream os = con.getOutputStream();
			        os.write(data.getBytes());
				}
			}
			responseCode = con.getResponseCode();
	//		System.out.println("\nSending '"+httpType+"' request to URL : " + url);
			
			//infolevel
			
			Loggers.log.info("Http Type: "+httpType+"\nUrl: "+url+ "\n"+"Response Code: "+responseCode );

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;

			while ((inputLine = in.readLine()) != null) 
			{
				response.append(inputLine);
			}
			in.close();
				
	//		System.out.println(response.toString());
			/*-----------------------------------------------
			JsonParser jpar 	= new JsonParser();
			 JsonElement jele = jpar.parse(response.toString());
			 
			 JsonObject jobj1 = new JsonObject();
			 
			 jobj1.add("response", jele);
			 
			String foundValue = jobj1.get("errors").getAsString();
			----------------------------------------------*/
		}
		catch(Exception e)
		{
			//errorlevel
			e.printStackTrace();
			if(responseCode == 400)
			{
				String msg= "Invalid Json_NewLine character is Missing";
	//			System.out.println(msg);
				throw new HttpException(responseCode, msg);
				
			}
			
			 
			 if(responseCode == 200 )
			 {
				 JsonParser jpar 	= new JsonParser();
				 JsonElement jele = jpar.parse(response.toString());
				 
				 JsonObject jobj1 = new JsonObject();
				 
				 jobj1.add("response", jele);
				 
				String foundValue = jobj1.get("errors").getAsString();
				if(foundValue == "true")
			 
				 
				 throw new HttpException(responseCode, response.toString());
			
			 }
		}
		resp[0] = Integer.toString(responseCode);
		
		resp[1] = response.toString();
	//	System.out.println("responseof0"+resp[0]+"responseof1"+resp[1]);
		return resp;
	}
}


