package com.parser.process;

import java.util.UUID;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.parser.util.HttpCalls;
import com.parser.util.Loggers;

public class SonarProcess {
	

	HttpCalls connectionUtil = new HttpCalls();

	public String getSonarData(String jsonStr) {
		
		
		
		String reponseJsonStr = "";
		JsonObject res = new JsonObject();
		try {

			JsonParser jp = new JsonParser();
			JsonArray ja = jp.parse(jsonStr).getAsJsonArray();
			for (JsonElement jsonElement : ja) {
				JsonObject jo = jsonElement.getAsJsonObject();
				JsonObject objectJo = new JsonObject();

				objectJo.addProperty("_index", "sonar");
				objectJo.addProperty("_type", "external");
				objectJo.addProperty("_id", UUID.randomUUID().toString()
						.replaceAll("-", ""));
				JsonObject indexJo = new JsonObject();
				indexJo.add("index", objectJo);
				reponseJsonStr += indexJo.toString() + "\n";
				reponseJsonStr += this.formatJson(jo).toString() + "\n";
			}
			//LOG4J
		   
		    
			
		//    Loggers.log.info("Hello this is an info message");
			
		//	System.out.println("Count: "+count);
			res.addProperty("status", true);
			res.addProperty("data", reponseJsonStr.toString());
			//System.out.println(res.toString());
		} catch (NullPointerException e) {
			//e.printStackTrace();
			Loggers.log.debug(e.getMessage() +"\n" + reponseJsonStr);
			Loggers.log.error(e.getMessage());
			reponseJsonStr = null;
			res.addProperty("status", false);
		} catch (Exception e) {
			//e.printStackTrace();
			Loggers.log.debug(e.getMessage() +"\n" + reponseJsonStr);
			Loggers.log.error(e.getMessage() + "\n" + e.getStackTrace());
			res.addProperty("status", false);
		}
	//	System.out.println("Fin "+reponseJsonStr);
		
		Loggers.log.debug("Sonar Response: "+reponseJsonStr);
		
		return reponseJsonStr;
		
	}

	public JsonObject formatJson(JsonObject oneProject) throws Exception {
		
	
		 
		JsonObject sonarObject = new JsonObject();
		sonarObject.addProperty("name", oneProject.get("name").getAsString());
		sonarObject.addProperty("date", oneProject.get("date").getAsString());
		sonarObject
				.addProperty("service", oneProject.get("name").getAsString());
		sonarObject.addProperty("project", "SharedService");
		sonarObject.addProperty("sprint", 18);
		sonarObject.addProperty("release", "R7.2");

		JsonArray jsonArray = oneProject.get("msr").getAsJsonArray();
		for (JsonElement msrElement : jsonArray) {
			JsonObject jo = msrElement.getAsJsonObject();
			String key = jo.get("key").getAsString();
			if (key.equalsIgnoreCase("sqale_rating")
					|| key.equalsIgnoreCase("alert_status")) {
				sonarObject.addProperty(key, jo.get("data").getAsString());
			} else {
				sonarObject.addProperty(key, jo.get("val").getAsNumber());
			}
		}
		 System.out.println("This is Sonar Object"+sonarObject);
		return sonarObject;
	}

}
