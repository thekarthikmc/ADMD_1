package com.parser.process;

import java.util.Properties;
import java.util.UUID;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.parser.bean.JenkinsBean;
import com.parser.util.HttpCalls;
import com.parser.util.Loggers;
import com.parser.util.PropertyValues;

public class JenkinsProcess {
	
	HttpCalls hc ;
	Properties prop ;

	public JenkinsProcess()
	{
		prop = PropertyValues.prop;
		this.hc = new HttpCalls();
	}
	
	public String jenkinsProcess(String jsonStr)
	{
			
//		System.out.println("JSON: "+jsonStr);
		JsonParser jp 	= new JsonParser();
		JsonArray ja 	= jp.parse(jsonStr).getAsJsonObject().get("jobs").getAsJsonArray();
		StringBuilder responseJsonStr 	= new StringBuilder();
		int count = 0;
		for (JsonElement jsonElement : ja) {
			
			JsonObject oneJob 		= jsonElement.getAsJsonObject();
			JenkinsBean bean 		= new JenkinsBean();
			
			if (oneJob.get("name").getAsString().contains("DEV")
					|| oneJob.get("name").getAsString().contains("CERT")) 
			{
				
				bean= bean.generateBean(oneJob);
				
				if (bean.hasTestCase()) {
					bean = this.getTestReportForJob(bean);
					
					JsonObject objectJo = new JsonObject();
					objectJo.addProperty("_index", "jenkins");
					objectJo.addProperty("_type", "external");
					objectJo.addProperty("_id", UUID.randomUUID().toString().replaceAll("-", ""));
					JsonObject indexJo= new JsonObject();
					indexJo.add("index", objectJo);
					
					responseJsonStr.append(indexJo.toString() +"\n");
					
					responseJsonStr.append(new Gson().toJson(bean)+"\n");					
					count++;
				}
			}
		}		
		System.out.println("Count: "+count);
		
		Loggers.log.debug("Jenkins Response: "+responseJsonStr.toString());
		
		return responseJsonStr.toString();
	}
	
	public JenkinsBean getTestReportForJob(JenkinsBean bean) {


		
		JsonObject jo 		= new JsonObject();
		String jsonStr 		= null;
		String[]respData 	= new String[2];
		try {
			respData 		= hc.httpCall(bean.getUrl()+ bean.getBuildNo()+ prop.getProperty("jenkinstestreport"), 
												null, Integer.parseInt(prop.getProperty("jenkinstimeout")), null, "GET");
			
			jsonStr			= respData[1];
			
	//		System.out.println(jsonStr);
			
			JsonParser jp 	= new JsonParser();
			jo 				= jp.parse(jsonStr).getAsJsonObject();
			
			bean.setFailCount(jo.get("failCount").getAsLong());
			bean.setPassCount(jo.get("passCount").getAsLong());
			bean.setSkipCount(jo.get("skipCount").getAsLong());
			bean.setTotalTestCase(bean.getPassCount()+bean.getFailCount()+bean.getSkipCount());
			
			float val 		=(bean.getPassCount()/bean.getTotalTestCase())*100;
			
	//		System.out.print(val);
			
			bean.setPercent(val);
			
		} 
		
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bean;
	}
	
}
