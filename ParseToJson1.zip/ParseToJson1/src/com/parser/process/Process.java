package com.parser.process;

import java.util.Properties;

import com.parser.elastic.ElasticAPI;
import com.parser.exceptions.ElasticException;
import com.parser.util.HttpCalls;
import com.parser.util.PropertyValues;

public class Process {

	
	
	HttpCalls hc ;
	Properties prop;
	
	public Process()
	{
		this.prop = PropertyValues.prop;
		this.hc = new HttpCalls();		
	}
	
	public void init(String tool)
	{
		String jsonStr 			= null;
		String bulkReq 	= "";
		String[]respData 		= new String[2];
		
		try {
			
			respData 		= hc.httpCall(prop.getProperty(tool)+prop.getProperty(tool+"param"), null, Integer.parseInt(prop.getProperty(tool+"timeout")), null, "GET");
			jsonStr 		= respData[1];
			
			//System.out.println("******************Jenkins**************");
			//System.out.println(jsonStr);		
			
			if("jenkins".equals(tool))
			{
				JenkinsProcess jp = new JenkinsProcess();
				bulkReq = jp.jenkinsProcess(jsonStr);
			}
			if("sonar".equals(tool))
			{
				SonarProcess sp = new SonarProcess();
				bulkReq = sp.getSonarData(jsonStr);
			}
			
			ElasticAPI eapi = new ElasticAPI(prop.getProperty("elasticUrl"), null, 10);
			try {
				eapi.bulkSave(bulkReq.toString());
			} catch (ElasticException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		//	System.out.println("******************Test Report**************");
			//System.out.println(bulkReq);
			
			//Logic to post into ElasticSearch
			
		} 
		
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}
	}
}
