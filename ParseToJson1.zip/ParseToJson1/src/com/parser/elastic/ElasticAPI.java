package com.parser.elastic;

import java.util.Map;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.parser.exceptions.ElasticException;
import com.parser.exceptions.HttpException;
import com.parser.util.HttpCalls;
import com.parser.util.Loggers;
import com.parser.util.PropertyValues;

public class ElasticAPI{

	String url;
	String elasticurl;
	Map<String,String> headers;
	int timeout;
	HttpCalls hc ;
	Properties prop;
	String bulkUrl;
	
	public ElasticAPI(String url, Map<String,String> headers, int timeout)
	{
		this.url = url;
		this.headers	= headers;
		this.timeout 	= timeout;
		prop = new PropertyValues().getProperties();
		hc = new HttpCalls();
		bulkUrl = prop.getProperty("bulkUrl");
		elasticurl = prop.getProperty("elasticUrl");
	}
	


	
	public void bulkSave(String index, String type, String data) throws ElasticException, HttpException
	{
		
		PropertyConfigurator.configure("log4j.properties");
		
		String params = "/"+index+"/"+type;
		
		String response[] = hc.httpCall(elasticurl+params+bulkUrl, headers, timeout, data, "POST");
		
		
		int code = Integer.parseInt(response[0]);			
		
		 
		 JsonParser jpar 	= new JsonParser();
		// JsonElement jele = jpar.parse(response[1]);
		 
		 JsonObject jobj1 = jpar.parse(response[1]).getAsJsonObject();
		 
		 
		String foundValue = jobj1.get("errors").getAsString();
		
		 if(code== 200 & foundValue.equalsIgnoreCase("true"))
		 {
			 Loggers.log.error("Invalid Json_Data _format");
			 throw new ElasticException(code, response[1]);
		 } 
			 if(code != 200)
			 {
				 	Loggers.log.error("Invalid Json_NewLine character is Missing");
					throw new ElasticException(code, response[1]);
			 }
	}
	
	public void bulkSave(String index, String data) throws ElasticException, HttpException
	{
		String params = "/"+index;
		String response[] = hc.httpCall(url+params+bulkUrl, headers, timeout, data, "POST");
		int code = Integer.parseInt(response[0]);
		if(code != 200)
		
			throw new ElasticException(code, response[1]);
		
		
		
	}
	
	public void bulkSave(String data) throws ElasticException, HttpException
	{
		String response[] = hc.httpCall(url+bulkUrl, headers, timeout, data, "POST");
		int code = Integer.parseInt(response[0]);
		if(code != 200)
			throw new ElasticException(code, response[1]);
	}
	
	public void singleSave(String index, String type, String data) throws ElasticException, HttpException
	{
		String params = index+"/"+type;
		String response[] = hc.httpCall(url+params, headers, timeout, data, "POST");
		int code = Integer.parseInt(response[0]);
		if(code != 200)
			throw new ElasticException(code, response[1]);
	}
	
	public void singleSave(String index, String type, String uid, String data) throws ElasticException, HttpException
	{
		String params = index+"/"+type+"/"+uid;
		String response[] = hc.httpCall(url+params, headers, timeout, data, "PUT");
		int code = Integer.parseInt(response[0]);
		if(code != 200)
			throw new ElasticException(code, response[1]);
	}
	
	public String getDataByID(String index, String type, String uid) throws ElasticException, HttpException
	{
		String params = index+"/"+type+"/"+uid;
		String response[] = hc.httpCall(url+params, headers, timeout, null, "GET");
		int code = Integer.parseInt(response[0]);
		if(code != 200)
			throw new ElasticException(code, response[1]);
		return response[1];
	}
}