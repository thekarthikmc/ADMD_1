package com.parser.main;

import java.util.Properties;
import java.util.StringTokenizer;

import com.parser.process.Process;
import com.parser.util.HttpCalls;
import com.parser.util.Loggers;
import com.parser.util.PropertyValues;

public class StartService {

	static HttpCalls hc;
	static Properties pro;
	

	public static void main(String args[]) {	
	//	System.out.println("************************Start Service Logs***********************");
		
		//PropertyConfigurator.configure("log4j.properties");
		
		Loggers.log.info("Started : Collecting Data");
		Properties prop  	= new PropertyValues().loadProperties();
		StringTokenizer st 	= new StringTokenizer(prop.getProperty("cqTools"),",");
		hc = new HttpCalls();
		pro = new PropertyValues().getProperties();
		
		while (st.hasMoreTokens()) {
			String tool = st.nextToken();
			new Process().init(tool);
	     }
	     
		Loggers.log.info("Ending : Data Collection ");
	}
}
