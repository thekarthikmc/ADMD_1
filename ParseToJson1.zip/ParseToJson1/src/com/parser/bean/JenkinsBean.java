package com.parser.bean;

import com.google.gson.JsonObject;

public class JenkinsBean {
	private String service;
	private String project = "SharedService";
	private int sprint = 17;
	private String release = "R7.2";
	private long date;
	private String buildType;
	private String jobType;
	private String envType;
	private long buildNo;
	private String status;
	private boolean hasTestCase;
	private long totalTestCase;
	private long failCount=0;
	private long passCount=0;
	private long skipCount=0;
	private float percent;
	private String url;

	public String getService() {
		return service;
	}

	public void setService(String service) {
		//System.out.println(service);
		if ("DEV".equals(this.envType)) {
			this.service = service.substring(0, service.indexOf("DEV") - 1);
		} else {
			this.service = service.substring(0, service.indexOf("CERT") - 1);
		}
		
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public int getSprint() {
		return sprint;
	}

	public void setSprint(int sprint) {
		this.sprint = sprint;
	}

	public String getRelease() {
		return release;
	}

	public void setRelease(String release) {
		this.release = release;
	}

	public long getDate() {
		return date;
	}

	public void setDate(long date) {
		this.date = date;
	}

	public String getBuildType() {
		return buildType;
	}

	public void setBuildType(String buildType) {
		this.buildType = buildType;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {

		if ("DEV".equals(this.envType)) {
			this.jobType = jobType.substring(jobType.indexOf("DEV") + 4);
		} else {
			this.jobType = jobType.substring(jobType.indexOf("CERT") + 5);
		}

	}

	public String getEnvType() {
		return envType;
	}

	public void setEnvType(String envType) {
		if (envType.contains("DEV")) {
			this.envType = "DEV";
		} else {
			this.envType = "CERT";
		}
	}

	public long getBuildNo() {
		return buildNo;
	}

	public void setBuildNo(long buildNo) {
		this.buildNo = buildNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getTotalTestCase() {
		return totalTestCase;
	}

	public void setTotalTestCase(long totalTestCase) {
		this.totalTestCase = totalTestCase;
	}

	public long getFailCount() {
		return failCount;
	}

	public void setFailCount(long failCount) {
		this.failCount = failCount;
	}

	public long getPassCount() {
		return passCount;
	}

	public void setPassCount(long passCount) {
		this.passCount = passCount;
	}

	public long getSkipCount() {
		return skipCount;
	}

	public void setSkipCount(long skipCount) {
		this.skipCount = skipCount;
	}

	public float getPercent() {
		return percent;
	}

	public void setPercent(float percent) {
		this.percent = percent;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public boolean hasTestCase() {
		return hasTestCase;
	}

	public void setHasTestCase(boolean isTestCase) {
		this.hasTestCase = isTestCase;
	}

	public JenkinsBean generateBean(JsonObject jo) {

		// check for job containing cert or dev before calling this
		
		this.setEnvType(jo.get("name").getAsString());
		
		

		this.setService(jo.get("name").getAsString());
		
		if (!jo.get("lastBuild").isJsonNull()) {
			
			System.out.println(jo.get("name").getAsString());
			System.out.println(jo.get("lastBuild").isJsonNull());
			
			JsonObject lastBuildObj = new JsonObject();

			this.setUrl(jo.get("url").getAsString());
			// check for health report
			if (jo.get("healthReport").getAsJsonArray().size() > 1) {
				this.setHasTestCase(true);
			} else {
				this.setHasTestCase(false);
			}
			try{
			lastBuildObj = jo.get("lastBuild").getAsJsonObject();
			
			this.setDate(lastBuildObj.get("timestamp").getAsLong());
			this.setBuildNo(lastBuildObj.get("number").getAsLong());
			this.setStatus(lastBuildObj.get("result").getAsString());
			this.setJobType(jo.get("name").getAsString());
		}catch(Exception e){
			System.out.println(lastBuildObj);
		}
			
		} 
		return this;

	}

}
